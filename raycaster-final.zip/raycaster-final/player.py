# player.py
import pyray as pr
import math
import config
from map import GameMap # Import GameMap for collision detection
from typing import Tuple, Optional, Dict, Any
import requests # Needed for HTTP requests
import time     # Needed for potential timeouts/retries
import json

# --- Joystick Input Handler ---
class JoystickInput:
    """Handles fetching state from the virtual joystick server."""
    def __init__(self, base_url: str, joystick_id: int, timeout: float = 0.5):
        self.url = f"{base_url}/api/joystick/{joystick_id}"
        self.joystick_id = joystick_id
        self.timeout = timeout # Request timeout in seconds
        self.last_state: Dict[str, Any] = {'xl': 0, 'yl': 0, 'xr': 0, 'bl': 0, 'br': 0}
        self.last_fetch_time: float = 0.0
        self.fetch_interval: float = 0.05 # Fetch state ~20 times per second

        print(f"JoystickInput initialized for ID {joystick_id} at {self.url}")
        # Try to create/ensure the joystick exists on the server
        try:
            create_url = f"{base_url}/api/createJoystick/{joystick_id}"
            response = requests.get(create_url, timeout=self.timeout)
            if response.status_code == 200:
                print(f"Ensured joystick ID {joystick_id} exists on server.")
            else:
                print(f"Warning: Failed to ensure joystick ID {joystick_id} on server (Status: {response.status_code}).")
        except requests.exceptions.RequestException as e:
            print(f"Warning: Could not contact joystick server during init: {e}")


    def get_state(self) -> Optional[Dict[str, Any]]:
        """
        Fetches the latest joystick state from the server.
        Returns the state dictionary or None if fetch fails.
        Caches the state for a short interval.
        """
        current_time = time.time()
        if current_time - self.last_fetch_time < self.fetch_interval:
            return self.last_state # Return cached state

        try:
            response = requests.get(self.url, timeout=self.timeout)
            response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
            self.last_state = response.json()
            #print(self.last_state)
            self.last_fetch_time = current_time
            # print(f"Joystick State: {self.last_state}") # Debug
            return self.last_state
        except requests.exceptions.RequestException as e:
            # print(f"Warning: Failed to fetch joystick state: {e}") # Can be noisy
            # Return the last known state on error to avoid jerky stops
            return self.last_state
        except json.JSONDecodeError:
            print(f"Warning: Received invalid JSON from joystick server.")
            return self.last_state # Return last known state


# --- Player Class ---
class Player:
    def __init__(self, x: float, y: float, angle: float, joystick_input: Optional[JoystickInput] = None):
        self.x = x
        self.y = y
        self.angle = angle # Radians
        self.health = config.PLAYER_HEALTH_START
        self.is_shooting = False
        self.is_dead = False
        self.is_running = False
        self.delta_time = 0.0 # Will be updated each frame
        self.score = 0
        self.joystick_input = joystick_input # Store the joystick handler
        self.damage = 6

    def handle_input(self, game_map: GameMap):
        """Processes player input for movement and actions, prioritizing joystick."""
        if self.is_dead:
            return

        # --- Input Variables ---
        move_forward = 0.0  # -1.0 (backward) to 1.0 (forward)
        move_strafe = 0.0   # -1.0 (left) to 1.0 (right)
        rotate = 0.0        # -1.0 (left) to 1.0 (right)
        shoot_pressed = False
        run_active = False
        joystick_active = False

        # --- Try Joystick Input ---
        if self.joystick_input:
            joy_state = self.joystick_input.get_state()
            if joy_state:
                joystick_active = False # Assume active if we get state

                # Joystick values are typically -100 to 100
                js_scale = 1
                dead_zone = 0 # Ignore small movements around center

                # Left Stick (Movement)
                raw_yl = joy_state.get('yl', 0)
                raw_xl = joy_state.get('xl', 0)

                # Apply dead zone and scale
                move_forward = raw_yl / js_scale if abs(raw_yl) > dead_zone else 0.0 # Y is often inverted
                move_strafe = raw_xl / js_scale if abs(raw_xl) > dead_zone else 0.0
                #print(f"{raw_xl} / {js_scale} ")

                # Right Stick (Rotation)
                raw_xr = joy_state.get('xr', 0)
                rotate = raw_xr / js_scale if abs(raw_xr) > dead_zone else 0.0

                # Buttons
                shoot_pressed = joy_state.get('bl', 0) == 1
                run_active = joy_state.get('br', 0) == 1


        # --- Fallback to Keyboard/Mouse if Joystick not active/available ---
        if not joystick_active:
            # Rotation
            if pr.is_key_down(pr.KeyboardKey.KEY_LEFT) or pr.is_key_down(pr.KeyboardKey.KEY_A):
                rotate = -1.0
            elif pr.is_key_down(pr.KeyboardKey.KEY_RIGHT) or pr.is_key_down(pr.KeyboardKey.KEY_D):
                rotate = 1.0

            # Movement
            if pr.is_key_down(pr.KeyboardKey.KEY_UP) or pr.is_key_down(pr.KeyboardKey.KEY_W):
                move_forward = 1.0
            elif pr.is_key_down(pr.KeyboardKey.KEY_DOWN) or pr.is_key_down(pr.KeyboardKey.KEY_S):
                move_forward = -1.0

            # Strafing (Optional - add keys if desired, e.g., Q/E)
            if pr.is_key_down(pr.KeyboardKey.KEY_Q): move_strafe = -1.0
            if pr.is_key_down(pr.KeyboardKey.KEY_E): move_strafe = 1.0
            # print("Hello")

            # Actions
            run_active = pr.is_key_down(pr.KeyboardKey.KEY_LEFT_SHIFT) or pr.is_key_down(pr.KeyboardKey.KEY_RIGHT_SHIFT)
            # Use mouse press for shooting only in keyboard mode
            shoot_pressed = pr.is_key_down(pr.KeyboardKey.KEY_SPACE)
            


        # --- Apply Input to Player State ---
        move_speed = config.PLAYER_MOVE_SPEED
        rot_speed = config.PLAYER_ROTATION_SPEED

        # Rotation
        self.angle += rotate * rot_speed * self.delta_time
        self.angle = self.angle % (2 * math.pi)
        if self.angle < 0:
            self.angle += (2 * math.pi)

        # Movement Speed (Running)
        self.is_running = run_active
        if self.is_running:
             move_speed *= config.PLAYER_RUN_MULTIPLIER

        # Calculate movement vector based on forward/strafe input
        move_step = move_speed * self.delta_time
        fwd_x = math.cos(self.angle) * move_forward * move_step
        fwd_y = math.sin(self.angle) * move_forward * move_step

        strafe_angle = self.angle + math.pi / 2.0 # Angle perpendicular to facing direction
        strafe_x = math.cos(strafe_angle) * move_strafe * move_step
        strafe_y = math.sin(strafe_angle) * move_strafe * move_step

        total_move_x = fwd_x + strafe_x
        total_move_y = fwd_y + strafe_y

        # Simple Collision Detection
        target_x = self.x + total_move_x
        target_y = self.y + total_move_y

        # Check collision separately for X and Y
        if not game_map.is_wall(target_x, self.y):
            self.x = target_x
        if not game_map.is_wall(self.x, target_y):
            self.y = target_y

        # Shooting (set flag for one frame if pressed)
        # Note: With joystick, this might stay true if button held.
        # Server should handle cooldowns/ammo.
        self.is_shooting = shoot_pressed
        
        if self.is_shooting:
            print("Shooting")


    def update(self, delta_time: float, game_map: GameMap):
        """Updates player state based on input and time."""
        self.delta_time = delta_time
        if not self.is_dead:
            self.handle_input(game_map)

        if self.health <= 0:
            self.is_dead = True

    def get_state_dict(self) -> dict:
        """Returns player state for network transmission."""
        return {
            "x": round(self.x, 4),
            "y": round(self.y, 4),
            "angle": round(self.angle, 4),
            "damage": self.damage,
            "health": self.health,
            "score": self.score,
            "is_shooting": self.is_shooting,
            "is_dead": self.is_dead,
            "is_running": self.is_running
        }

    def apply_server_update(self, data: dict):
        """Applies authoritative state updates from the server."""
        self.health = data.get("health", self.health)
        self.is_dead = data.get("is_dead", self.is_dead)
        self.score = data.get("score", self.score)
        # Server could potentially force position/angle here if needed

    def get_pos_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)

    def get_dir_vector(self) -> Tuple[float, float]:
        return (math.cos(self.angle), math.sin(self.angle))

    def get_plane_vector(self) -> Tuple[float, float]:
        """Returns the camera plane vector perpendicular to the direction."""
        dir_x = math.cos(self.angle)
        dir_y = math.sin(self.angle)
        # FOV scaling factor (adjust for desired FOV)
        scale = math.tan(config.PLAYER_FOV / 2.0) # More direct FOV control
        plane_x = -dir_y * scale
        plane_y = dir_x * scale
        return (plane_x, plane_y)

