# remote_player.py
import math
from typing import Optional
from typing import Tuple
import config

# Global variables to hold observer state (set by renderer)
# This is a simplification; passing player state explicitly is better practice
player_pos: Tuple[float, float] = (0.0, 0.0)
player_angle_rad: float = 0.0

def set_observer_state(pos: Tuple[float, float], angle: float):
    """Updates the global observer state needed for sprite direction calculation."""
    global player_pos, player_angle_rad
    player_pos = pos
    player_angle_rad = angle

class RemotePlayer:
    def __init__(self, player_id: str, data: dict):
        self.id = player_id
        self.x: float = 0.0
        self.y: float = 0.0
        self.angle: float = 0.0 # This player's facing angle (from server)
        self.health: int = 100
        self.is_shooting: bool = False
        self.is_dead: bool = False
        self.is_running: bool = False
        self.is_walking: bool = False # Determine based on position change
        self.last_update_time: float = 0.0
        self.last_x: float = 0.0
        self.last_y: float = 0.0
        self.sprite_name = "WinterGuard" # Default sprite set

        self.update_from_server(data) # Initialize with first data packet

    def update_from_server(self, data: dict):
        """Updates the state of this remote player from server data."""
        new_x = data.get("x", self.x)
        new_y = data.get("y", self.y)
        new_angle = data.get("angle", self.angle) # Get angle from server

        # Determine if walking/running based on position change and server flag
        # Threshold check helps ignore minor network jitter
        pos_changed = abs(new_x - self.x) > 0.01 or abs(new_y - self.y) > 0.01

        self.is_running = data.get("is_running", False) and pos_changed
        # Consider walking if position changed but not running
        self.is_walking = (not self.is_running) and pos_changed

        self.last_x = self.x
        self.last_y = self.y
        self.x = new_x
        self.y = new_y
        self.angle = new_angle # Update the player's facing angle
        self.health = data.get("health", self.health)
        self.is_shooting = data.get("is_shooting", False)
        self.is_dead = data.get("is_dead", False)
        # self.last_update_time = pr.get_time() # If using interpolation

    def get_texture_index(self) -> int:
        """
        Determines the correct sprite index based on state (idle/walk/run)
        and the relative angle between this player's facing direction and
        the direction towards the observer (local player).

        User-specified Mapping Target: Index 1:Front, Index 3:Left, Index 5:Back, Index 7:Right
        (Assuming _1.png is index 0, _2.png is index 1 etc.)
        """
        if self.is_dead:
            # Using the first idle frame (index 0) as placeholder for dead
            # Adjust if you have a specific dead sprite/index
            return config.SPRITE_WINTERGUARD_IDLE_START - 1 # 0-based index

        # --- Calculate Relative Angle ---
        # 1. Angle from observer (local player) to this remote player
        dx = self.x - player_pos[0]
        dy = self.y - player_pos[1]
        # Avoid division by zero or undefined angle if observer is exactly at sprite position
        if abs(dx) < 1e-6 and abs(dy) < 1e-6:
            angle_to_sprite = 0.0 # Default angle if positions overlap
        else:
            angle_to_sprite = math.atan2(dy, dx)


        # 2. Angle difference between the remote player's facing direction (self.angle)
        #    and the direction *towards* the observer (angle_to_sprite + pi).
        #    This tells us which side of the remote player the observer is looking at.
        delta_angle = self.angle - (angle_to_sprite + math.pi)

        # 3. Normalize angle difference to be between -pi and +pi
        while delta_angle <= -math.pi: delta_angle += 2 * math.pi
        while delta_angle > math.pi: delta_angle -= 2 * math.pi

        # --- Map Relative Angle to Direction Index (0-7) ---
        # Base calculation maps: 0:Front, 2:Left, 4:Back, 6:Right
        # Formula uses (-delta_angle) to flip the rotation direction for indexing.
        # Using floor for stability instead of round.
        normalized_angle = (-delta_angle + math.pi) / (2 * math.pi) # Range 0.0 to 1.0
        base_direction_index = math.floor(normalized_angle * config.SPRITE_DIRECTIONS)

        # --- SHIFT INDEX TO MATCH USER REQUIREMENT ---
        # Add 1 to shift the index (0->1, 1->2, ..., 7->0)
        # The modulo ensures it wraps around correctly (7+1=8 -> 0)
        direction_index = (base_direction_index + 1) % config.SPRITE_DIRECTIONS

        # --- Determine State Base Index ---
        # Use constants from config.py for clarity
        if self.is_running:
             base_index = config.SPRITE_WINTERGUARD_RUN_START # Should be 17
        elif self.is_walking:
            # Defaulting walk to use run sprites
            base_index = config.SPRITE_WINTERGUARD_RUN_START
            # Use this if you have separate walk sprites (e.g., 9-16)
            # base_index = config.SPRITE_WINTERGUARD_WALK_START
        else: # Idle
             base_index = config.SPRITE_WINTERGUARD_IDLE_START # Should be 1

        # --- Calculate Final Texture Index ---
        # Texture file index is 1-based (e.g., WinterGuard_1.png)
        # Add the calculated (and shifted) direction offset (0-7) to the 1-based state start index
        texture_file_index = base_index + direction_index

        # Return the 0-based index for AssetsManager list access
        # print(f"Player {self.id}: State={'Run' if self.is_running else 'Walk' if self.is_walking else 'Idle'}, Angle={math.degrees(self.angle):.1f}, Delta={math.degrees(delta_angle):.1f}, BaseDirIdx={base_direction_index}, ShiftedDirIdx={direction_index}, FileIdx={texture_file_index}") # Debug
        return texture_file_index

    def get_pos_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)

    def should_draw(self) -> bool:
        """Determines if the player should be drawn (e.g., not dead)."""
        return not self.is_dead