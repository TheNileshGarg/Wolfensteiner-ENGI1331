# remote_player.py
import math
from typing import Optional
from typing import Tuple
import config

# Global variables to hold observer state (set by renderer)
# This is a simplification; passing player state explicitly is better practice
player_pos: Tuple[float, float] = (0.0, 0.0) # Position is no longer used for direction index
player_angle_rad: float = 0.0 # Observer's angle IS used

def set_observer_state(pos: Tuple[float, float], angle: float):
    """Updates the global observer state needed for sprite direction calculation."""
    global player_pos, player_angle_rad
    player_pos = pos
    player_angle_rad = angle

class RemotePlayer:
    def __init__(self, player_id: str, data: dict):
        self.id = player_id
        self.x: float = 0.0
        self.y: float = 0.0
        self.angle: float = 0.0 # This player's facing angle (from server)
        self.health: int = 100
        self.is_shooting: bool = False
        self.is_dead: bool = False
        self.is_running: bool = False
        self.is_walking: bool = False # Determine based on position change
        self.last_update_time: float = 0.0
        self.last_x: float = 0.0
        self.last_y: float = 0.0
        self.sprite_name = "WinterGuard" # Default sprite set

        self.update_from_server(data) # Initialize with first data packet

    def update_from_server(self, data: dict):
        """Updates the state of this remote player from server data."""
        new_x = data.get("x", self.x)
        new_y = data.get("y", self.y)
        new_angle = data.get("angle", self.angle) # Get angle from server

        # Determine if walking/running based on position change and server flag
        # Threshold check helps ignore minor network jitter
        pos_changed = abs(new_x - self.x) > 0.01 or abs(new_y - self.y) > 0.01

        self.is_running = data.get("is_running", False) and pos_changed
        # Consider walking if position changed but not running
        self.is_walking = (not self.is_running) and pos_changed

        self.last_x = self.x
        self.last_y = self.y
        self.x = new_x
        self.y = new_y
        self.angle = new_angle # Update the player's facing angle
        self.health = data.get("health", self.health)
        self.is_shooting = data.get("is_shooting", False)
        self.is_dead = data.get("is_dead", False)
        # self.last_update_time = pr.get_time() # If using interpolation

    def get_texture_index(self) -> int:
        """
        Determines the correct sprite index based on state (idle/walk/run)
        and the relative angle between this remote player's facing direction
        and the local player's (observer's) facing direction.

        Returns a 1-based index (e.g., 1-8 for idle, 17-24 for running)
        as expected by AssetsManager.

        User-specified Mapping Target: Index 1:Front, Index 3:Left, Index 5:Back, Index 7:Right
        (and diagonals 0, 2, 4, 6 mapped to the corresponding 1-based indices)
        """
        if self.is_dead:
            # Return 1-based index for the first idle frame as placeholder for dead
            # Adjust if you have a specific dead sprite/index
            return config.SPRITE_WINTERGUARD_IDLE_START # Returns 1

        # --- Calculate Relative Angle based ONLY on view angles ---
        remote_angle = self.angle        # Remote player's facing direction
        observer_angle = player_angle_rad # Local player's facing direction

        # Calculate the angle difference representing the remote player's orientation
        # relative to the direction *opposite* the observer's view.
        delta_angle = remote_angle - (observer_angle + math.pi)

        # Normalize angle difference to be between -pi and +pi
        while delta_angle <= -math.pi: delta_angle += 2 * math.pi
        while delta_angle > math.pi: delta_angle -= 2 * math.pi

        # --- Map Relative Angle to Direction Index (0-7) ---
        # This part maps the delta angle to an intermediate index 0-7
        # where the final desired output index corresponds to:
        # 1 (Front), 2 (Front-Left), 3 (Left), 4 (Back-Left),
        # 5 (Back), 6 (Back-Right), 7 (Right), 8 (Front-Right)
        shifted_angle = delta_angle + (math.pi / 4.0)
        normalized_shifted_angle = shifted_angle + math.pi
        base_index = math.floor((normalized_shifted_angle / (2 * math.pi)) * config.SPRITE_DIRECTIONS)
        direction_index = (base_index + 4) % config.SPRITE_DIRECTIONS # Result is 0-7

        # --- Determine State Base Index (1-based) ---
        # Use constants from config.py for clarity
        if self.is_running:
             base_index_offset = config.SPRITE_WINTERGUARD_RUN_START # 17
        elif self.is_walking:
            # Defaulting walk to use run sprites
            base_index_offset = config.SPRITE_WINTERGUARD_RUN_START # 17
            # Use this if you have separate walk sprites (e.g., 9-16)
            # base_index_offset = config.SPRITE_WINTERGUARD_WALK_START # 9
        else: # Idle
             base_index_offset = config.SPRITE_WINTERGUARD_IDLE_START # 1

        # --- Calculate Final Texture Index (1-based) ---
        # Add the calculated direction offset (0-7) to the 1-based state start index
        texture_file_index = base_index_offset + direction_index # Result is 1-8 or 17-24 etc.

        # Return the 1-based index directly
        # print(f"Player {self.id}: State={'Run' if self.is_running else 'Walk' if self.is_walking else 'Idle'}, RemAng={math.degrees(remote_angle):.1f}, ObsAng={math.degrees(observer_angle):.1f}, Delta={math.degrees(delta_angle):.1f}, DirIdx={direction_index}, FileIdx={texture_file_index}") # Debug
        return texture_file_index

    def get_pos_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)

    def should_draw(self) -> bool:
        """Determines if the player should be drawn (e.g., not dead)."""
        return not self.is_dead